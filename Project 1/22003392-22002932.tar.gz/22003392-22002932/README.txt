name: ali kaan sahin
id: 22002932
name: tarik berkan bilge
id: 22003392
